"""Portable launcher for retained harnesses; paths are explicit and outputs fresh.

Install accelerator-toolbox0.9.0 and build the supplied FixedDeltaBlockPass first.
This changes only path bindings; each underlying harness freezes its run inputs.
"""
from pathlib import Path
import argparse,sys,hashlib,importlib


def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('campaign',choices=['qualification-native','qualification-compiled','qualification-fused','qualification-audit','confirmation','backcheck','diagnostics'])
 p.add_argument('--runtime',type=Path)
 p.add_argument('--source',type=Path,required=True)
 p.add_argument('--compiler-dir',type=Path,required=True)
 p.add_argument('--output',type=Path,required=True)
 p.add_argument('--reference-dir',type=Path)
 args=p.parse_args()
 if args.runtime:sys.path.insert(0,str(args.runtime.resolve()))
 import qualification_bnl as q
 if q.at.__version__!='0.9.0':raise ValueError('Pinned accelerator-toolbox==0.9.0 required')
 if hashlib.sha256(args.source.read_bytes()).hexdigest()!='cbe4cbdc19ddec39e2e999c5337bf7cde93113570fd0639ac1e03007aa8355cb':raise ValueError('This launcher reproduces the pinned public BNL model; new models need a new declared protocol.')
 q.SOURCE=args.source.resolve();q.COMPILER=args.compiler_dir.resolve()/'compiler.py';q.OUT=args.output.resolve()
 args.output.parent.mkdir(parents=True,exist_ok=True)
 if args.campaign.startswith('qualification-'):
  phase=args.campaign.split('-',1)[1]
  if phase=='fused'and not(q.OUT/'protocol_addendum_fused.json').exists():
   raise ValueError('Supply the prospectively frozen fused addendum before a fused qualification replay.')
  sys.argv=[str(Path(q.__file__)),'--phase',phase];q.main()
 elif args.campaign=='confirmation':
  import confirmation_bnl as c
  c.LAB=args.compiler_dir.resolve();c.OUT=args.output.resolve();c.main()
 elif args.campaign=='backcheck':
  if args.reference_dir is None:raise ValueError('--reference-dir required for the retained128-point backcheck')
  import backcheck_bnl as b
  sys.argv=[str(Path(b.__file__)),'--source',str(args.source.resolve()),'--compiler-dir',str(args.compiler_dir.resolve()),'--reference-dir',str(args.reference_dir.resolve()),'--output',str(args.output.resolve())]
  b.main()
 else:
  raise ValueError('Diagnostics are retained evidence; use diagnose_boundaries.py from a relocated copy with its declared reference paths. No automatic new variant selection.')


if __name__=='__main__':main()
